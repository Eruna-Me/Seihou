﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seihou
{ 
    class Nothing : Pattern
    {
        public Nothing(float time,EntityManager em,Boss daddy) : base(time,em,daddy)
        {

        }
    }
}
